#include "ItemTracker.h"
#include <iostream>
#include <fstream>
#include <string>

// Constructor
ItemTracker::ItemTracker() {
    // Load data from frequency.dat (if available)
    loadFrequencyData();
}

// Destructor
ItemTracker::~ItemTracker() {
    // Save data to frequency.dat
    saveFrequencyData();
}

// Function to add item and update frequency
void ItemTracker::addItem(const std::string& item) {
    itemFrequency[item]++;
}

// Function to get frequency of a specific item
int ItemTracker::getItemFrequency(const std::string& item) {
    return itemFrequency[item];
}

// Function to print item frequencies
void ItemTracker::printFrequencies() {
    for (const auto& pair : itemFrequency) {
        std::cout << pair.first << " " << pair.second << std::endl;
    }
}

// Function to print item frequencies as a histogram
void ItemTracker::printHistogram() {
    for (const auto& pair : itemFrequency) {
        std::cout << pair.first << " ";
        for (int i = 0; i < pair.second; ++i) {
            std::cout << "*";
        }
        std::cout << std::endl;
    }
}

// Function to remove item and update frequency
void ItemTracker::removeItem(const std::string& item) {
    if (itemFrequency.find(item) != itemFrequency.end() && itemFrequency[item] > 0) {
        itemFrequency[item]--;
    }
    else {
        std::cout << "Item not found in inventory or frequency is already 0." << std::endl;
    }
}

// Load frequency data from the Inventory.txt file
void ItemTracker::loadFrequencyData() {
    std::ifstream file("Inventory.txt"); 
    if (file.is_open()) {
        std::string word;
        while (file >> word) {
            itemFrequency[word]++;
        }
        file.close();
    }
    else {
        std::cout << "Unable to open Inventory.txt" << std::endl;
    }
}

// Save frequency data to file
void ItemTracker::saveFrequencyData() {
    std::ofstream file("frequency.dat");
    if (file.is_open()) {
        for (const auto& pair : itemFrequency) {
            file << pair.first << " " << pair.second << std::endl;
        }
        file.close();
    }
}
