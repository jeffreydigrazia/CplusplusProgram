#include <iostream>
#include "itemTracker.h"

int main() {

    // declare itemTracker object
    ItemTracker itemTracker;

    // choice variables
    int choice;
    std::string item;



    // loop to print function until 6 is entered
    do {
        std::cout << "Menu:\n";
        std::cout << "1. Add Item\n";
        std::cout << "2. Print Frequencies\n";
        std::cout << "3. Print Histogram\n";
        std::cout << "4. Search Item and Frequency\n";
        std::cout << "5. Remove Item\n";
        std::cout << "6. Exit\n";
        std::cout << "Enter your choice: ";
        std::cin >> choice;

        switch (choice) {
        case 1:
            std::cout << "Enter the item: ";
            std::cin >> item;
            itemTracker.addItem(item);
            break;
        case 2:
            itemTracker.printFrequencies();
            break;
        case 3:
            itemTracker.printHistogram();
            break;
            // searches for Item and item frequency also checks if it exists
        case 4:
            std::cout << "Enter the item name to search for: ";
            std::cin >> item;
            if (itemTracker.getItemFrequency(item) > 0) {
                std::cout << "Frequency of " << item << ": " << itemTracker.getItemFrequency(item) << std::endl;
            }
            else {
                std::cout << "Item not found in inventory." << std::endl;
            }
            break;
        case 5:
            std::cout << "Enter the item name to remove: ";
            std::cin >> item;
            itemTracker.removeItem(item);
            break;
        case 6:
            std::cout << "Exiting program\n";
            break;
        default:
            std::cout << "Invalid choice. Please try again.\n";
        }
    } while (choice != 6);

    return 0;
}
