#ifndef ITEM_TRACKER_H
#define ITEM_TRACKER_H

#include <iostream>
#include <fstream>
#include <string>
#include <map>

class ItemTracker {
private:
    std::map<std::string, int> itemFrequency;

public:
    // Constructor
    ItemTracker();

    // Destructor
    ~ItemTracker();

    // Function to add item and update frequency
    void addItem(const std::string& item);

    // Function to get frequency of a specific item
    int getItemFrequency(const std::string& item);

    // Function to print item frequencies
    void printFrequencies();

    // Function to print item frequencies as a histogram
    void printHistogram();

    // Function to remove item and update frequency
    void removeItem(const std::string& item);

private:
    // Load frequency data from the Inventory.txt file
    void loadFrequencyData();

    // Save frequency data to file
    void saveFrequencyData();
};

#endif // ITEM_TRACKER_H
